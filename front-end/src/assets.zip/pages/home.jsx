import { useState, useEffect } from "react";
import MovieCard from "../components/moviecard.jsx";
import "../css/home.css";
import { searchMovies, getPopularMovies } from "../services/api.js";

const formatMovie = (m) => ({
  id: m.imdbID,
  title: m.Title || "Unknown",
  year: m.Year || "N/A",
  poster:
    m.Poster && m.Poster !== "N/A"
      ? m.Poster
      : "https://via.placeholder.com/300x450?text=No+Image",
});

function Home() {
  const [searchQuery, setSearchQuery] = useState("");
  const [movies, setMovies] = useState([]);
  const [totalResults, setTotalResults] = useState(0);
  const [page, setPage] = useState(1);
  const [loading, setLoading] = useState(true);

  const totalPages = Math.ceil(totalResults / 10);

  const loadPopular = async (pageNum = 1) => {
    setLoading(true);
    const response = await getPopularMovies(pageNum);

    setMovies(response.Search ? response.Search.map(formatMovie) : []);
    setTotalResults(Number(response.totalResults) || 0);
    setPage(pageNum);
    setLoading(false);
  };

  useEffect(() => {
    loadPopular();
  }, []);

  const handleSearch = async (text, pageNum = 1) => {
    setSearchQuery(text);

    if (!text.trim()) {
      loadPopular(1);
      return;
    }

    setLoading(true);

    const response = await searchMovies(text, pageNum);

    setMovies(response.Search ? response.Search.map(formatMovie) : []);
    setTotalResults(Number(response.totalResults) || 0);
    setPage(pageNum);
    setLoading(false);
  };

  return (
    <div className="home">
      <form className="Search-form" onSubmit={(e) => e.preventDefault()}>
        <input
          type="text"
          placeholder="Search movies..."
          className="Search-input"
          value={searchQuery}
          onChange={(e) => handleSearch(e.target.value, 1)}
        />
      </form>

      {loading && (
        <div className="movie-grid">
          {Array.from({ length: 10 }).map((_, i) => (
            <div key={i} className="movie-skeleton" />
          ))}
        </div>
      )}

      {!loading && movies.length === 0 && (
        <div className="status-text empty-text">🔍 No movies found.</div>
      )}

      {!loading && movies.length > 0 && (
        <>
          <div className="movie-grid">
            {movies.map((movie) => (
              <MovieCard key={movie.id} movie={movie} />
            ))}
          </div>

          {totalPages > 1 && (
            <div className="pagination">
              <button
                className="page-btn"
                disabled={page === 1}
                onClick={() =>
                  searchQuery
                    ? handleSearch(searchQuery, page - 1)
                    : loadPopular(page - 1)
                }
              >
                ⬅ Prev
              </button>

              <span className="page-indicator">
                Page {page} / {totalPages}
              </span>

              <button
                className="page-btn"
                disabled={page === totalPages}
                onClick={() =>
                  searchQuery
                    ? handleSearch(searchQuery, page + 1)
                    : loadPopular(page + 1)
                }
              >
                Next ➡
              </button>
            </div>
          )}
        </>
      )}
    </div>
  );
}

export default Home;
